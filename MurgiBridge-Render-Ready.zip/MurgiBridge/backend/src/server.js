require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');
const Razorpay = require('razorpay');

const app = express();
const PORT = Number(process.env.PORT || 4000);
const JWT_SECRET = process.env.JWT_SECRET || '';
const DATABASE_URL = process.env.DATABASE_URL || '';
const KEY_ID = process.env.RAZORPAY_KEY_ID || '';
const KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || '';
const WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET || '';
const production = process.env.NODE_ENV === 'production';
const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : undefined, max: 10 }) : null;
const razorpay = KEY_ID && KEY_SECRET ? new Razorpay({ key_id: KEY_ID, key_secret: KEY_SECRET }) : null;

if (production && (!JWT_SECRET || JWT_SECRET.length < 32)) throw new Error('JWT_SECRET must be at least 32 characters in production');
if (production && !pool) throw new Error('DATABASE_URL is required in production');

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(morgan(production ? 'combined' : 'dev'));
const origins = (process.env.CORS_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
app.use(cors({ origin: origins.length ? origins : (production ? false : true), methods: ['GET','POST','PATCH','DELETE','OPTIONS'], allowedHeaders: ['Content-Type','Authorization'] }));
// Razorpay webhook must receive the exact raw request bytes for signature validation.
app.post('/payments/webhook', express.raw({ type: 'application/json', limit: '1mb' }), async (req, res) => {
  try {
    if (!WEBHOOK_SECRET) return res.status(503).send('Webhook secret not configured');
    const signature = req.headers['x-razorpay-signature'];
    const expected = crypto.createHmac('sha256', WEBHOOK_SECRET).update(req.body).digest('hex');
    const a = Buffer.from(String(signature || ''), 'hex'); const b = Buffer.from(expected, 'hex');
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(400).send('Invalid webhook signature');
    const event = JSON.parse(req.body.toString('utf8'));
    const entity = event?.payload?.payment?.entity;
    if (entity?.order_id && ['payment.captured','payment.failed'].includes(event.event) && pool) {
      const status = event.event === 'payment.captured' ? 'captured' : 'failed';
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const p = await client.query('UPDATE payments SET status=$1, provider_payment_id=COALESCE(provider_payment_id,$2), raw_payload=$3, updated_at=NOW() WHERE provider_order_id=$4 RETURNING order_id', [status, entity.id, event, entity.order_id]);
        if (status === 'captured' && p.rowCount) await client.query("UPDATE orders SET status='paid', updated_at=NOW() WHERE id=$1 AND status='pending'", [p.rows[0].order_id]);
        await client.query('COMMIT');
      } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
    }
    res.json({ received: true });
  } catch (e) { console.error('webhook:', e.message); res.status(500).send('Webhook processing failed'); }
});
app.use(express.json({ limit: '1mb' }));
app.use('/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false }));

const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const db = async (sql, params=[]) => { if (!pool) throw Object.assign(new Error('Database is not configured. Set DATABASE_URL.'), { status: 503 }); return pool.query(sql, params); };
const tokenFor = user => jwt.sign({ sub: String(user.id), role: user.role }, JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d', issuer: 'murgibridge' });
const auth = asyncRoute(async (req,res,next) => {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i,'');
  if (!token) return res.status(401).json({ error: 'Authentication required' });
  try { const decoded = jwt.verify(token, JWT_SECRET, { issuer: 'murgibridge' }); const r = await db('SELECT id,name,email,phone,role,is_active FROM users WHERE id=$1', [decoded.sub]); if (!r.rowCount || !r.rows[0].is_active) return res.status(401).json({ error: 'Account unavailable' }); req.user = r.rows[0]; next(); }
  catch (e) { if (e.name === 'JsonWebTokenError' || e.name === 'TokenExpiredError') return res.status(401).json({ error: 'Invalid or expired token' }); throw e; }
});
const roles = (...allowed) => (req,res,next) => allowed.includes(req.user.role) ? next() : res.status(403).json({ error: 'Permission denied' });
const safeUser = u => ({ id: u.id, name: u.name, email: u.email, phone: u.phone, role: u.role, city: u.city, state: u.state });

app.get('/health', asyncRoute(async (_req,res) => res.json({ ok:true, service:'murgibridge-api', databaseConfigured:!!pool, razorpayConfigured:!!razorpay, mode: production ? 'production' : 'development' })));
app.get('/api/config', (_req,res) => res.json({ razorpayKeyId: KEY_ID, currency:'INR', appName:'MurgiBridge', paymentsEnabled:!!razorpay }));

app.post('/auth/register', asyncRoute(async (req,res) => {
  const { name, email, phone, password, role='farmer', city, state } = req.body || {};
  if (!name || String(name).trim().length < 2 || !password || String(password).length < 8 || (!email && !phone)) return res.status(400).json({ error:'Name, email or phone, and password (minimum 8 characters) are required' });
  if (!['farmer','buyer','seller'].includes(role)) return res.status(400).json({ error:'Invalid account role' });
  const hash = await bcrypt.hash(String(password), 12);
  try { const r = await db('INSERT INTO users(name,email,phone,password_hash,role,city,state) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id,name,email,phone,role,city,state', [String(name).trim(), email ? String(email).toLowerCase().trim() : null, phone ? String(phone).trim() : null, hash, role, city || null, state || null]); const user = r.rows[0]; res.status(201).json({ user, token:tokenFor(user) }); }
  catch(e) { if (e.code === '23505') return res.status(409).json({ error:'Email or phone is already registered' }); throw e; }
}));
app.post('/auth/login', asyncRoute(async (req,res) => {
  const { identifier, password } = req.body || {}; if (!identifier || !password) return res.status(400).json({ error:'Identifier and password are required' });
  const r = await db('SELECT * FROM users WHERE lower(email)=lower($1) OR phone=$1 LIMIT 1', [String(identifier).trim()]);
  if (!r.rowCount || !r.rows[0].is_active || !(await bcrypt.compare(String(password), r.rows[0].password_hash))) return res.status(401).json({ error:'Incorrect login details' });
  res.json({ user:safeUser(r.rows[0]), token:tokenFor(r.rows[0]) });
}));
app.get('/auth/me', auth, (req,res) => res.json({ user:req.user }));
app.patch('/auth/me', auth, asyncRoute(async (req,res) => { const { name,city,state }=req.body||{}; const r=await db('UPDATE users SET name=COALESCE($1,name),city=COALESCE($2,city),state=COALESCE($3,state),updated_at=NOW() WHERE id=$4 RETURNING id,name,email,phone,role,city,state',[name||null,city||null,state||null,req.user.id]); res.json({user:r.rows[0]}); }));

app.get('/listings', asyncRoute(async (req,res) => { const { category, q, city, page='1', limit='20' }=req.query; const p=Math.max(1,Number(page)||1), n=Math.min(50,Math.max(1,Number(limit)||20)); const vals=[]; let where="l.status='active'"; if(category){vals.push(category);where+=` AND l.category=$${vals.length}`;} if(city){vals.push(`%${city}%`);where+=` AND l.city ILIKE $${vals.length}`;} if(q){vals.push(`%${q}%`);where+=` AND (l.title ILIKE $${vals.length} OR l.description ILIKE $${vals.length} OR l.breed ILIKE $${vals.length})`;} vals.push(n,(p-1)*n); const r=await db(`SELECT l.id,l.title,l.category,l.breed,l.description,l.quantity,l.unit,l.price_paise,l.city,l.state,l.image_url,l.created_at,u.id seller_id,u.name seller_name FROM listings l JOIN users u ON u.id=l.seller_id WHERE ${where} ORDER BY l.created_at DESC LIMIT $${vals.length-1} OFFSET $${vals.length}`,vals); res.json({items:r.rows,page:p,limit:n}); }));
app.post('/listings', auth, asyncRoute(async (req,res) => { const { title,category,breed,description,quantity,unit='kg',pricePaise,city,state,imageUrl }=req.body||{}; if(!title||!['birds','chicks','feed','medicine','equipment','other'].includes(category)||!(Number(quantity)>0)||!(Number.isSafeInteger(Number(pricePaise))&&Number(pricePaise)>0)) return res.status(400).json({error:'Valid title, category, quantity and pricePaise are required'}); const r=await db('INSERT INTO listings(seller_id,title,category,breed,description,quantity,unit,price_paise,city,state,image_url) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *',[req.user.id,title,category,breed||null,description||null,quantity,unit,pricePaise,city||null,state||null,imageUrl||null]); res.status(201).json({listing:r.rows[0]}); }));
app.patch('/listings/:id', auth, asyncRoute(async (req,res) => { const {status,pricePaise,quantity}=req.body||{}; const r=await db("UPDATE listings SET status=COALESCE($1,status),price_paise=COALESCE($2,price_paise),quantity=COALESCE($3,quantity),updated_at=NOW() WHERE id=$4 AND (seller_id=$5 OR $6='admin') RETURNING *",[status||null,pricePaise||null,quantity||null,req.params.id,req.user.id,req.user.role]); if(!r.rowCount)return res.status(404).json({error:'Listing not found or not yours'}); res.json({listing:r.rows[0]}); }));

app.post('/orders', auth, asyncRoute(async (req,res) => { const { listingId,quantity,deliveryAddress }=req.body||{}; if(!(Number(quantity)>0)||!deliveryAddress)return res.status(400).json({error:'Quantity and delivery address are required'}); const c=await pool.connect(); try { await c.query('BEGIN'); const l=await c.query("SELECT * FROM listings WHERE id=$1 AND status='active' FOR UPDATE",[listingId]); if(!l.rowCount){await c.query('ROLLBACK');return res.status(404).json({error:'Listing unavailable'});} const item=l.rows[0]; if(String(item.seller_id)===String(req.user.id)){await c.query('ROLLBACK');return res.status(400).json({error:'You cannot buy your own listing'});} if(Number(quantity)>Number(item.quantity)){await c.query('ROLLBACK');return res.status(400).json({error:'Requested quantity is unavailable'});} const total= Math.round(Number(quantity)*Number(item.price_paise)); if(!Number.isSafeInteger(total)||total<=0)return res.status(400).json({error:'Invalid order total'}); const o=await c.query('INSERT INTO orders(buyer_id,seller_id,listing_id,quantity,unit_price_paise,total_paise,delivery_address) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *',[req.user.id,item.seller_id,item.id,quantity,item.price_paise,total,deliveryAddress]); await c.query('UPDATE listings SET quantity=quantity-$1,updated_at=NOW(),status=CASE WHEN quantity-$1<=0 THEN \'sold\' ELSE status END WHERE id=$2',[quantity,item.id]); await c.query('COMMIT'); res.status(201).json({order:o.rows[0]}); } catch(e){await c.query('ROLLBACK');throw e;} finally{c.release();} }));
app.get('/orders', auth, asyncRoute(async (req,res) => { const admin=req.user.role==='admin'; const r=await db(`SELECT o.*,l.title listing_title,b.name buyer_name,s.name seller_name,p.status payment_status,p.provider_payment_id FROM orders o JOIN listings l ON l.id=o.listing_id JOIN users b ON b.id=o.buyer_id JOIN users s ON s.id=o.seller_id LEFT JOIN payments p ON p.order_id=o.id WHERE ($1 OR o.buyer_id=$2 OR o.seller_id=$2) ORDER BY o.created_at DESC LIMIT 100`,[admin,req.user.id]); res.json({items:r.rows}); }));
app.patch('/orders/:id/status', auth, asyncRoute(async (req,res) => { const {status}=req.body||{}; const allowed=['confirmed','packed','shipped','delivered','cancelled']; if(!allowed.includes(status))return res.status(400).json({error:'Invalid status'}); const r=await db("UPDATE orders SET status=$1,updated_at=NOW() WHERE id=$2 AND ((seller_id=$3 AND $1 IN ('confirmed','packed','shipped')) OR (buyer_id=$3 AND $1 IN ('delivered','cancelled')) OR $4='admin') RETURNING *",[status,req.params.id,req.user.id,req.user.role]); if(!r.rowCount)return res.status(404).json({error:'Order not found or transition not permitted'}); res.json({order:r.rows[0]}); }));

app.post('/payments/create-order', auth, asyncRoute(async (req,res) => { if(!razorpay)return res.status(503).json({error:'Razorpay is not configured'}); const {orderId}=req.body||{}; if(!orderId)return res.status(400).json({error:'orderId is required'}); const o=await db("SELECT * FROM orders WHERE id=$1 AND buyer_id=$2 AND status='pending'",[orderId,req.user.id]); if(!o.rowCount)return res.status(404).json({error:'Pending order not found'}); const order=o.rows[0]; const receipt=`mb_order_${order.id}_${Date.now()}`.slice(0,40); const rp=await razorpay.orders.create({amount:Number(order.total_paise),currency:'INR',receipt,notes:{murgibridge_order_id:String(order.id)}}); await db("INSERT INTO payments(order_id,provider_order_id,amount_paise) VALUES($1,$2,$3) ON CONFLICT(order_id) DO UPDATE SET provider_order_id=EXCLUDED.provider_order_id,amount_paise=EXCLUDED.amount_paise,status='created',updated_at=NOW()",[order.id,rp.id,rp.amount]); res.status(201).json({id:rp.id,amount:rp.amount,currency:rp.currency,receipt:rp.receipt,keyId:KEY_ID}); }));
app.post('/payments/verify', auth, asyncRoute(async (req,res) => { const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body||{}; if(!razorpay_order_id||!razorpay_payment_id||!razorpay_signature)return res.status(400).json({verified:false,message:'Payment verification fields are required'}); const p=await db('SELECT p.*,o.buyer_id FROM payments p JOIN orders o ON o.id=p.order_id WHERE p.provider_order_id=$1',[razorpay_order_id]); if(!p.rowCount||String(p.rows[0].buyer_id)!==String(req.user.id))return res.status(404).json({verified:false,message:'Payment record not found'}); const expected=crypto.createHmac('sha256',KEY_SECRET).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex'); const a=Buffer.from(expected,'hex'),b=Buffer.from(String(razorpay_signature),'hex'); if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return res.status(400).json({verified:false,message:'Invalid payment signature'}); const payment=await razorpay.payments.fetch(razorpay_payment_id); if(payment.order_id!==razorpay_order_id||payment.status!=='captured'||Number(payment.amount)!==Number(p.rows[0].amount_paise))return res.status(409).json({verified:false,message:'Payment is not captured or amount does not match'}); const c=await pool.connect(); try{await c.query('BEGIN'); await c.query("UPDATE payments SET provider_payment_id=$1,status='captured',method=$2,raw_payload=$3,updated_at=NOW() WHERE order_id=$4",[payment.id,payment.method,payment,p.rows[0].order_id]); await c.query("UPDATE orders SET status='paid',updated_at=NOW() WHERE id=$1 AND status='pending'",[p.rows[0].order_id]); await c.query('COMMIT');}catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();} res.json({verified:true,message:'Payment captured and verified'}); }));

app.post('/consultations', auth, asyncRoute(async (req,res)=>{const {subject,question,imageUrl}=req.body||{};if(!subject||!question)return res.status(400).json({error:'Subject and question are required'});const r=await db('INSERT INTO consultations(user_id,subject,question,image_url) VALUES($1,$2,$3,$4) RETURNING *',[req.user.id,subject,question,imageUrl||null]);res.status(201).json({consultation:r.rows[0]});}));
app.get('/consultations', auth, asyncRoute(async(req,res)=>{const admin=['admin','doctor'].includes(req.user.role);const r=await db('SELECT c.*,u.name user_name,e.name expert_name FROM consultations c JOIN users u ON u.id=c.user_id LEFT JOIN users e ON e.id=c.expert_id WHERE ($1 OR c.user_id=$2) ORDER BY c.created_at DESC LIMIT 100',[admin,req.user.id]);res.json({items:r.rows});}));
app.patch('/consultations/:id/answer', auth, roles('doctor','admin'), asyncRoute(async(req,res)=>{const {answer,status='answered'}=req.body||{};if(!answer)return res.status(400).json({error:'Answer is required'});const r=await db("UPDATE consultations SET answer=$1,status=$2,expert_id=$3,updated_at=NOW() WHERE id=$4 RETURNING *",[answer,status,req.user.id,req.params.id]);if(!r.rowCount)return res.status(404).json({error:'Consultation not found'});res.json({consultation:r.rows[0]});}));

app.get('/admin/overview',auth,roles('admin'),asyncRoute(async(_req,res)=>{const r=await db("SELECT (SELECT COUNT(*) FROM users) users,(SELECT COUNT(*) FROM listings WHERE status='active') active_listings,(SELECT COUNT(*) FROM orders) orders,(SELECT COUNT(*) FROM orders WHERE status='paid') paid_orders,(SELECT COALESCE(SUM(amount_paise),0) FROM payments WHERE status='captured') captured_paise,(SELECT COUNT(*) FROM consultations WHERE status='open') open_consultations");res.json(r.rows[0]);}));
app.patch('/admin/users/:id/status',auth,roles('admin'),asyncRoute(async(req,res)=>{const {active}=req.body||{};if(typeof active!=='boolean')return res.status(400).json({error:'active boolean required'});const r=await db('UPDATE users SET is_active=$1,updated_at=NOW() WHERE id=$2 RETURNING id,name,email,phone,role,is_active',[active,req.params.id]);if(!r.rowCount)return res.status(404).json({error:'User not found'});res.json({user:r.rows[0]});}));

app.use('/api', (_req,res)=>res.status(404).json({error:'API route not found'}));
app.use((err,_req,res,_next)=>{console.error(err);const status=err.status||500;res.status(status).json({error:production&&status===500?'Internal server error':err.message||'Request failed'});});

async function start(){
  if(pool){const migration=fs.readFileSync(path.join(__dirname,'migrations','001_init.sql'),'utf8');await pool.query(migration);}
  if(process.env.ADMIN_EMAIL&&process.env.ADMIN_PASSWORD&&pool){const hash=await bcrypt.hash(process.env.ADMIN_PASSWORD,12);await pool.query("INSERT INTO users(name,email,password_hash,role) VALUES('MurgiBridge Admin',$1,$2,'admin') ON CONFLICT(email) DO NOTHING",[process.env.ADMIN_EMAIL.toLowerCase(),hash]);}
  app.listen(PORT,()=>console.log(`MurgiBridge API listening on ${PORT}; DB ${pool?'connected':'not configured'}; Razorpay ${razorpay?'configured':'not configured'}`));
}
start().catch(e=>{console.error('Startup failed:',e);process.exit(1);});
