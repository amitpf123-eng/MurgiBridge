# MurgiBridge API v2

Node 20 + Express + PostgreSQL + JWT + Razorpay. No mock payment path is present. Payments are enabled only when real Razorpay credentials are configured.

## Local deployment

1. Install Docker Desktop / Docker Engine and Node 20+.
2. `cp .env.example .env` and set a unique `POSTGRES_PASSWORD`, `JWT_SECRET` (32+ random characters), Razorpay test keys, webhook secret and admin credentials.
3. Add `POSTGRES_PASSWORD=...` to `.env` (used by Compose).
4. `docker compose up --build -d`
5. Check `GET http://localhost:4000/health`.

The SQL migration is applied automatically at startup. Keep persistent PostgreSQL volume backups. Put the API behind HTTPS before public use.

## Main endpoints

- `POST /auth/register` `{name,email?,phone?,password,role?,city?,state?}`
- `POST /auth/login` `{identifier,password}`
- `GET/PATCH /auth/me` (Bearer token)
- `GET /listings?category=&q=&city=&page=&limit=`
- `POST /listings`, `PATCH /listings/:id` (authenticated seller)
- `POST /orders` `{listingId,quantity,deliveryAddress}`; server calculates the amount
- `GET /orders`; `PATCH /orders/:id/status`
- `POST /payments/create-order` `{orderId}`; amount is loaded from the owned pending order, never trusted from the client
- `POST /payments/verify` `{razorpay_order_id,razorpay_payment_id,razorpay_signature}`
- `POST /consultations`, `GET /consultations`, `PATCH /consultations/:id/answer` (doctor/admin)
- `GET /admin/overview`, `PATCH /admin/users/:id/status` (admin)

All protected routes require `Authorization: Bearer <token>`. Amounts are integer paise. Currency is INR. The Razorpay webhook route verifies the HMAC against the exact raw request bytes and updates captured/failed payments.

## Important release requirements

- Use Razorpay TEST keys until checkout, webhook delivery and refunds are tested. Switch to LIVE keys only after merchant KYC and approval.
- Configure Razorpay webhook URL as `https://YOUR_API_HOST/payments/webhook` and subscribe to `payment.captured` and `payment.failed`.
- Set `CORS_ORIGINS` to exact trusted admin origins; use HTTPS, managed PostgreSQL, backups, monitoring and secrets manager in production.
- Admin seed is created only when `ADMIN_EMAIL` and `ADMIN_PASSWORD` are set; change credentials after first login. The admin web UI still needs to be connected to these authenticated endpoints before operational use.
- File/image upload storage, OTP/SMS delivery, delivery-partner integration, escrow/legal arrangements, refunds/disputes and mobile marketplace UI wiring require provider accounts and deployment configuration; these are not simulated by this API.
