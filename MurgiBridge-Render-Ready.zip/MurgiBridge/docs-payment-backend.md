# Razorpay setup (mobile + backend)

Full backend code is in the **`backend/`** folder.

## Quick start

```bash
# 1. Backend
cd backend
cp .env.example .env
# Fill RAZORPAY_KEY_ID + RAZORPAY_KEY_SECRET
npm install
npm run dev

# 2. Mobile app.json
# "extra": {
#   "razorpayKeyId": "rzp_test_xxxx",
#   "paymentApiUrl": "http://YOUR_IP:4000"
# }

# 3. Mobile
cd ..
npm install
npx eas build --platform android --profile preview
```

See `backend/README.md` for API details and deploy notes.
