# Deploy MurgiBridge on Render

This repository includes `render.yaml` at its root. It defines a Node.js API service and a managed PostgreSQL database. The API runs database migrations at startup.

## 1. Put this project in GitHub

1. Sign in to GitHub and create a **private** repository named `MurgiBridge`.
2. Upload/push the contents of this project so `render.yaml` is at the repository root (not inside a nested folder).
3. Do not upload `.env` files, API secrets, or production credentials.

## 2. Create the Render services

1. Sign in to Render: https://dashboard.render.com/
2. Choose **New + → Blueprint**.
3. Connect GitHub and select the `MurgiBridge` repository.
4. Render reads `render.yaml` and previews the API and PostgreSQL resources. Review the plans and displayed charges before applying.
5. During initial setup, enter the prompted secret values:
   - `ADMIN_EMAIL`: an email address you control.
   - `ADMIN_PASSWORD`: a long, unique password (store it in a password manager).
   - `CORS_ORIGINS`: the exact HTTPS origin(s) of the admin website, comma-separated. If the admin UI is not hosted yet, use the value `https://example.invalid` temporarily and replace it before using the browser admin UI.
   - `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`: use Razorpay **TEST** credentials initially. Do not use live credentials until the full checkout and webhook flow has been tested and merchant approval is complete.
6. Apply the Blueprint and wait for the API deployment to finish.

## 3. Verify the API

Open `https://YOUR-API-SERVICE.onrender.com/health`. A healthy response should include `ok: true`, `databaseConfigured: true`, and the service name `murgibridge-api`.

Then open `https://YOUR-API-SERVICE.onrender.com/api/config`. Confirm the payment configuration reflects whether Razorpay keys were entered. Do not share secret values or screenshots containing them.

## 4. Configure Razorpay TEST webhook

In the Razorpay dashboard, add this webhook URL:

`https://YOUR-API-SERVICE.onrender.com/payments/webhook`

Subscribe to `payment.captured` and `payment.failed`, and set the webhook secret to the exact same value entered as `RAZORPAY_WEBHOOK_SECRET` in Render.

## 5. Finish app integration after the API URL exists

The deployed API URL must then be added to the Expo app configuration (`expo.extra.apiBaseUrl` in `app.json`) and used for a fresh EAS build. The current mobile screens are not yet fully connected to all marketplace/order/consultation APIs. Do not publish or accept real customer payments until those flows, the admin dashboard, refunds/disputes, privacy policy, image storage, OTP and physical-device tests are completed.

## Cost and security notes

The Blueprint uses a paid Render Starter web service and a paid basic PostgreSQL plan; check the current price shown in your Render dashboard before creating resources. Render may change plan names/prices. Keep the database private to the service where possible, use HTTPS, rotate credentials if exposed, and configure backups/monitoring.

## Troubleshooting

- Build errors: confirm `render.yaml` is at the repository root and the API's `rootDir` is `backend`.
- Database connection errors: confirm the Blueprint-created database is available and `DATABASE_URL` is populated from the database resource.
- CORS errors in the browser dashboard: set `CORS_ORIGINS` to the dashboard's exact origin, including `https://` and no trailing path.
- Payment unavailable: confirm all three Razorpay values are set and the API redeployed.
