import React, { useEffect, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { ActivityIndicator, View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Home, ShoppingCart, TrendingUp, BookOpen, User } from 'lucide-react-native';

import { LanguageProvider } from './src/context/LanguageContext';
import HomeScreen from './src/screens/HomeScreen';
import BuyScreen from './src/screens/BuyScreen';
import SellScreen from './src/screens/SellScreen';
import TrainingScreen from './src/screens/TrainingScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import MandiDetailScreen from './src/screens/MandiDetailScreen';
import LiveTrainingScreen from './src/screens/LiveTrainingScreen';
import ExpertOpinionScreen from './src/screens/ExpertOpinionScreen';
import PaymentScreen from './src/screens/PaymentScreen';
import TrackingScreen from './src/screens/TrackingScreen';
import PrivacyPolicyScreen from './src/screens/PrivacyPolicyScreen';
import AuthScreen from './src/screens/AuthScreen';
import { clearToken, getToken, apiRequest } from './src/services/api';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function MainTabs({ onLogout }: { onLogout: () => void }) {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: '#166534',
        tabBarInactiveTintColor: '#94a3b8',
        tabBarStyle: {
          backgroundColor: '#ffffff',
          borderTopWidth: 1,
          borderTopColor: '#e2e8f0',
          height: 60,
          paddingBottom: 8,
          paddingTop: 6,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '600',
        },
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size }) => <Home color={color} size={size} />,
        }}
      />
      <Tab.Screen
        name="Buy"
        component={BuyScreen}
        options={{
          tabBarLabel: 'Kharido',
          tabBarIcon: ({ color, size }) => <ShoppingCart color={color} size={size} />,
        }}
      />
      <Tab.Screen
        name="Sell"
        component={SellScreen}
        options={{
          tabBarLabel: 'Becho',
          tabBarIcon: ({ color, size }) => <TrendingUp color={color} size={size} />,
        }}
      />
      <Tab.Screen
        name="Training"
        component={TrainingScreen}
        options={{
          tabBarLabel: 'Training',
          tabBarIcon: ({ color, size }) => <BookOpen color={color} size={size} />,
        }}
      />
      <Tab.Screen
        name="Profile"
        component={(props: any) => <ProfileScreen {...props} onLogout={onLogout} />}
        options={{
          tabBarLabel: 'Profile',
          tabBarIcon: ({ color, size }) => <User color={color} size={size} />,
        }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  const [session, setSession] = useState<'loading'|'signedOut'|'signedIn'>('loading');
  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const token = await getToken();
        if (!token) { if (active) setSession('signedOut'); return; }
        await apiRequest('/auth/me');
        if (active) setSession('signedIn');
      } catch { await clearToken(); if (active) setSession('signedOut'); }
    })();
    return () => { active = false; };
  }, []);
  if (session === 'loading') return <View style={{flex:1,alignItems:'center',justifyContent:'center',backgroundColor:'#f8fafc'}}><ActivityIndicator size="large" color="#166534"/><Text style={{marginTop:12,color:'#64748b'}}>Connecting to MurgiBridge…</Text></View>;
  if (session === 'signedOut') return <LanguageProvider><StatusBar style="dark"/><AuthScreen onAuthenticated={() => setSession('signedIn')} /></LanguageProvider>;
  return (
    <LanguageProvider>
      <NavigationContainer>
        <StatusBar style="light" />
        <Stack.Navigator>
          <Stack.Screen
            name="MainTabs"
            component={() => <MainTabs onLogout={async () => { await clearToken(); setSession('signedOut'); }} />}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="MandiDetail"
            component={MandiDetailScreen}
            options={{
              title: 'Mandi Listing',
              headerStyle: { backgroundColor: '#166534' },
              headerTintColor: '#fff',
            }}
          />
          <Stack.Screen
            name="LiveTraining"
            component={LiveTrainingScreen}
            options={{
              title: 'Live Training Session',
              headerStyle: { backgroundColor: '#166534' },
              headerTintColor: '#fff',
            }}
          />
          <Stack.Screen
            name="ExpertOpinion"
            component={ExpertOpinionScreen}
            options={{
              title: 'Expert / Doctor Opinion',
              headerStyle: { backgroundColor: '#166534' },
              headerTintColor: '#fff',
            }}
          />
          <Stack.Screen
            name="Payment"
            component={PaymentScreen}
            options={{
              title: 'Secure Payment',
              headerStyle: { backgroundColor: '#166534' },
              headerTintColor: '#fff',
            }}
          />
          <Stack.Screen
            name="Tracking"
            component={TrackingScreen}
            options={{
              title: 'Live Tracking',
              headerStyle: { backgroundColor: '#166534' },
              headerTintColor: '#fff',
            }}
          />
          <Stack.Screen
            name="PrivacyPolicy"
            component={PrivacyPolicyScreen}
            options={{
              title: 'Privacy Policy',
              headerStyle: { backgroundColor: '#166534' },
              headerTintColor: '#fff',
            }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </LanguageProvider>
  );
}
