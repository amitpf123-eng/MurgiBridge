import Constants from 'expo-constants';

/**
 * Razorpay configuration (production-oriented)
 * Set in app.json → expo.extra:
 *   razorpayKeyId: "rzp_live_xxx" or "rzp_test_xxx"
 *   paymentApiUrl: "https://your-api.com"
 */

const extra = Constants.expoConfig?.extra ?? {};

export const PAYMENT_CONFIG = {
  razorpayKeyId: (extra.razorpayKeyId as string) || '',
  apiBaseUrl: (extra.paymentApiUrl as string) || '',
  companyName: 'MurgiBridge',
  themeColor: '#166534',
  currency: 'INR' as const,
  /** Must stay false for Play Store builds — no fake successful payments */
  allowDemoFallback: false,
};

export function isRazorpayConfigured(): boolean {
  const key = PAYMENT_CONFIG.razorpayKeyId;
  return typeof key === 'string' && key.startsWith('rzp_') && key.length > 12;
}

export function isPaymentApiConfigured(): boolean {
  return typeof PAYMENT_CONFIG.apiBaseUrl === 'string' && PAYMENT_CONFIG.apiBaseUrl.startsWith('http');
}

export function amountToPaise(amountStr: string): number {
  const cleaned = String(amountStr).replace(/,/g, '').replace(/[^\d.]/g, '');
  const rupees = parseFloat(cleaned);
  if (isNaN(rupees) || rupees <= 0) return 0;
  return Math.round(rupees * 100);
}

export function formatRupees(paise: number): string {
  const rupees = paise / 100;
  return rupees.toLocaleString('en-IN', { maximumFractionDigits: 0 });
}
