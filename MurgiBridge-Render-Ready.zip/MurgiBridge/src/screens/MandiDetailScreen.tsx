import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { useRoute } from '@react-navigation/native';

const MANDI_NAMES: Record<string, string> = {
  local: 'Local Buyers / Sellers',
  district: 'District Mandi',
  state: 'State Mandi',
  international: 'International Mandi',
};

export default function MandiDetailScreen() {
  const route = useRoute<any>();
  const mandiType = route.params?.mandiType || 'local';

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>{MANDI_NAMES[mandiType]}</Text>
      <Text style={styles.sub}>
        Yahan apni ready murgi list karke seedha bech sakte hain
      </Text>

      <View style={styles.formCard}>
        <Text style={styles.label}>Murgi Type</Text>
        <TextInput style={styles.input} placeholder="Broiler / Layer / Desi / Kadaknath" />

        <Text style={styles.label}>Birds ki Sankhya</Text>
        <TextInput style={styles.input} placeholder="e.g. 500" keyboardType="numeric" />

        <Text style={styles.label}>Average Weight (kg)</Text>
        <TextInput style={styles.input} placeholder="e.g. 2.1" keyboardType="decimal-pad" />

        <Text style={styles.label}>Expected Rate (₹/kg)</Text>
        <TextInput style={styles.input} placeholder="e.g. 105" keyboardType="numeric" />

        <Text style={styles.label}>Location / Pickup Point</Text>
        <TextInput style={styles.input} placeholder="Village / Farm address" />

        <TouchableOpacity style={styles.submitBtn}>
          <Text style={styles.submitText}>Listing Publish Karein</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.note}>
        Note: Listing ke baad relevant buyers ko notification jayega. Aap direct baat kar sakte hain.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 16, paddingBottom: 40 },
  title: { fontSize: 20, fontWeight: '700', color: '#1e293b' },
  sub: { fontSize: 13, color: '#64748b', marginTop: 4, marginBottom: 20 },
  formCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
  },
  label: { fontSize: 13, fontWeight: '600', color: '#475569', marginBottom: 6, marginTop: 10 },
  input: {
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    color: '#1e293b',
  },
  submitBtn: {
    backgroundColor: '#166534',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 20,
  },
  submitText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  note: { fontSize: 12, color: '#64748b', lineHeight: 18 },
});
