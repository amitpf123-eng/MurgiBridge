import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';
import {
  BookOpen,
  Video,
  Camera,
  Upload,
  Stethoscope,
  Users,
  MessageCircle,
  Phone,
  FileText,
  PlayCircle,
} from 'lucide-react-native';

const TRAINING_STEPS = [
  { id: 1, title: 'Farm Planning & Enquiry', status: 'completed' },
  { id: 2, title: 'Farm Open / Restart', status: 'completed' },
  { id: 3, title: 'Chooja Purchase Guide', status: 'current' },
  { id: 4, title: 'Housing & Preparation', status: 'pending' },
  { id: 5, title: 'Daily Rakh-Rakhav', status: 'pending' },
  { id: 6, title: 'Feed Schedule', status: 'pending' },
  { id: 7, title: 'Vaccination Chart', status: 'pending' },
  { id: 8, title: 'Disease Management', status: 'pending' },
  { id: 9, title: 'Selling & Marketing', status: 'pending' },
];

export default function TrainingScreen() {
  const navigation = useNavigation<any>();

  const pickAndUpload = async (fromCamera: boolean) => {
    const camera = await ImagePicker.requestCameraPermissionsAsync();
    const media = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (camera.status !== 'granted' || media.status !== 'granted') {
      Alert.alert('Permission Required', 'Camera aur gallery access allow karein.');
      return;
    }
    try {
      const result = fromCamera
        ? await ImagePicker.launchCameraAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            quality: 0.8,
            allowsEditing: true,
          })
        : await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            quality: 0.8,
            allowsEditing: true,
          });
      if (!result.canceled && result.assets?.[0]?.uri) {
        Alert.alert(
          'Photo Attached',
          'Photo select ho gayi. Expert opinion ke liye bhej sakte hain.',
          [
            {
              text: 'Expert Opinion',
              onPress: () => navigation.navigate('ExpertOpinion', { type: 'doctor' }),
            },
            { text: 'OK' },
          ]
        );
      }
    } catch {
      Alert.alert('Error', 'Image select nahi ho saki.');
    }
  };

  const handleUpload = () => {
    Alert.alert(
      'Upload Media',
      'Photo upload karke expert se opinion le sakte hain',
      [
        { text: 'Camera', onPress: () => pickAndUpload(true) },
        { text: 'Gallery', onPress: () => pickAndUpload(false) },
        { text: 'Cancel', style: 'cancel' },
      ]
    );
  };

  const handleAiScan = () => {
    Alert.alert(
      'AI Disease Scan',
      'Camera se bird ki photo lein. AI analysis production version mein available hoga.',
      [
        { text: 'Open Camera', onPress: () => pickAndUpload(true) },
        { text: 'Cancel', style: 'cancel' },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Training Center</Text>
        <Text style={styles.headerSub}>
          Step-by-step guide + Expert & Doctor support
        </Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Progress */}
        <View style={styles.progressCard}>
          <Text style={styles.progressTitle}>Aapka Progress</Text>
          <View style={styles.progressBarBg}>
            <View style={[styles.progressBarFill, { width: '33%' }]} />
          </View>
          <Text style={styles.progressText}>3 / 9 Steps Complete</Text>
        </View>

        {/* Expert & Doctor Section */}
        <Text style={styles.sectionTitle}>Expert & Doctor Opinion</Text>
        <View style={styles.expertRow}>
          <TouchableOpacity
            style={[styles.expertCard, { backgroundColor: '#ecfdf5' }]}
            onPress={() => navigation.navigate('ExpertOpinion', { type: 'doctor' })}
          >
            <Stethoscope color="#166534" size={28} />
            <Text style={styles.expertTitle}>Poultry Doctor</Text>
            <Text style={styles.expertSub}>Bimari & Treatment</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.expertCard, { backgroundColor: '#eff6ff' }]}
            onPress={() => navigation.navigate('ExpertOpinion', { type: 'expert' })}
          >
            <Users color="#1d4ed8" size={28} />
            <Text style={styles.expertTitle}>Farm Expert</Text>
            <Text style={styles.expertSub}>Palan & Management</Text>
          </TouchableOpacity>
        </View>

        {/* Upload & Live Training */}
        <Text style={styles.sectionTitle}>Media & Live Training</Text>
        <View style={styles.actionRow}>
          <TouchableOpacity style={styles.actionBtn} onPress={handleUpload}>
            <Upload color="#166534" size={22} />
            <Text style={styles.actionText}>Photo / Video{'\n'}Upload</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionBtn}
            onPress={() => navigation.navigate('LiveTraining')}
          >
            <PlayCircle color="#dc2626" size={22} />
            <Text style={styles.actionText}>Live Training{'\n'}Session</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionBtn} onPress={handleAiScan}>
            <Camera color="#7c3aed" size={22} />
            <Text style={styles.actionText}>AI Disease{'\n'}Scan</Text>
          </TouchableOpacity>
        </View>

        {/* Contact Options */}
        <View style={styles.contactCard}>
          <Text style={styles.contactTitle}>Turant Madad Chahiye?</Text>
          <View style={styles.contactRow}>
            <TouchableOpacity style={styles.contactBtn}>
              <MessageCircle color="#166534" size={18} />
              <Text style={styles.contactBtnText}>AI Chat</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.contactBtn}>
              <Phone color="#166534" size={18} />
              <Text style={styles.contactBtnText}>Call</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.contactBtn}>
              <FileText color="#166534" size={18} />
              <Text style={styles.contactBtnText}>SMS</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Step by Step Roadmap */}
        <Text style={styles.sectionTitle}>Pura Training Roadmap</Text>
        {TRAINING_STEPS.map((step, index) => (
          <View key={step.id} style={styles.stepRow}>
            <View
              style={[
                styles.stepCircle,
                step.status === 'completed' && styles.stepCompleted,
                step.status === 'current' && styles.stepCurrent,
              ]}
            >
              <Text style={styles.stepNumber}>{step.id}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text
                style={[
                  styles.stepTitle,
                  step.status === 'current' && { color: '#166534', fontWeight: '700' },
                ]}
              >
                {step.title}
              </Text>
              {step.status === 'current' && (
                <Text style={styles.stepCurrentLabel}>Abhi yeh step chal raha hai</Text>
              )}
            </View>
            {step.status === 'completed' && (
              <Text style={styles.doneBadge}>✓</Text>
            )}
          </View>
        ))}

        {/* PDF Download */}
        <TouchableOpacity style={styles.pdfBtn}>
          <FileText color="#fff" size={20} />
          <Text style={styles.pdfBtnText}>
            Full Poultry Farm Business Guide (PDF) – Hindi + English
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  header: {
    backgroundColor: '#166534',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 18,
  },
  headerTitle: { color: '#fff', fontSize: 22, fontWeight: '700' },
  headerSub: { color: '#bbf7d0', fontSize: 13, marginTop: 4 },
  content: { padding: 16, paddingBottom: 40 },
  progressCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16,
    marginBottom: 18,
  },
  progressTitle: { fontSize: 14, fontWeight: '700', color: '#1e293b', marginBottom: 8 },
  progressBarBg: {
    height: 8,
    backgroundColor: '#e2e8f0',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: 8,
    backgroundColor: '#166534',
    borderRadius: 4,
  },
  progressText: { fontSize: 12, color: '#64748b', marginTop: 6 },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
    marginTop: 4,
  },
  expertRow: { flexDirection: 'row', gap: 12, marginBottom: 18 },
  expertCard: {
    flex: 1,
    borderRadius: 14,
    padding: 16,
    alignItems: 'center',
  },
  expertTitle: { fontSize: 14, fontWeight: '700', color: '#1e293b', marginTop: 8 },
  expertSub: { fontSize: 11, color: '#64748b', marginTop: 2 },
  actionRow: { flexDirection: 'row', gap: 10, marginBottom: 18 },
  actionBtn: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  actionText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#1e293b',
    textAlign: 'center',
    marginTop: 6,
  },
  contactCard: {
    backgroundColor: '#ecfdf5',
    borderRadius: 14,
    padding: 14,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: '#bbf7d0',
  },
  contactTitle: { fontSize: 14, fontWeight: '700', color: '#166534', marginBottom: 10 },
  contactRow: { flexDirection: 'row', gap: 10 },
  contactBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    paddingVertical: 10,
    borderRadius: 10,
    gap: 6,
  },
  contactBtnText: { fontSize: 13, fontWeight: '600', color: '#166534' },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    gap: 12,
  },
  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#e2e8f0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepCompleted: { backgroundColor: '#166534' },
  stepCurrent: { backgroundColor: '#f59e0b' },
  stepNumber: { color: '#fff', fontWeight: '700', fontSize: 13 },
  stepTitle: { fontSize: 14, color: '#1e293b' },
  stepCurrentLabel: { fontSize: 11, color: '#b45309', marginTop: 2 },
  doneBadge: { color: '#166534', fontSize: 18, fontWeight: '700' },
  pdfBtn: {
    backgroundColor: '#166534',
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    marginTop: 12,
  },
  pdfBtnText: { color: '#fff', fontWeight: '700', fontSize: 13, flex: 1 },
});
