import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking,
  Alert,
} from 'react-native';
import { useRoute } from '@react-navigation/native';
import {
  MapPin,
  Navigation,
  Truck,
  Phone,
  Clock,
  Package,
} from 'lucide-react-native';

export default function TrackingScreen() {
  const route = useRoute<any>();
  const orderType = route.params?.orderType || 'purchase'; // purchase | sell
  const isPurchase = orderType === 'purchase';

  const openGoogleMaps = () => {
    // Demo coordinates (can be replaced with real lat/lng)
    const lat = 26.8467;
    const lng = 80.9462;
    const label = isPurchase
      ? 'Delivery Vehicle - Feed & Chicks'
      : 'Pickup Vehicle - Ready Birds';

    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=driving`;
    Linking.openURL(url).catch(() =>
      Alert.alert('Error', 'Google Maps open nahi ho saka')
    );
  };

  const openMapsSearch = () => {
    const query = isPurchase
      ? 'Poultry Feed Supplier near me'
      : 'Poultry Market near me';
    const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
    Linking.openURL(url);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.statusCard}>
        <View style={styles.statusIcon}>
          <Truck color="#166534" size={32} />
        </View>
        <Text style={styles.statusTitle}>
          {isPurchase ? 'Delivery On The Way' : 'Pickup Vehicle Coming'}
        </Text>
        <Text style={styles.statusSub}>
          {isPurchase
            ? 'Feed + Chicks aapke farm ki taraf ja rahe hain'
            : 'Buyer ka vehicle aapke farm se birds lene aa raha hai'}
        </Text>
      </View>

      {/* Live Tracking Info */}
      <View style={styles.infoCard}>
        <View style={styles.infoRow}>
          <Clock color="#166534" size={18} />
          <Text style={styles.infoLabel}>Estimated Time</Text>
          <Text style={styles.infoValue}>32 mins</Text>
        </View>
        <View style={styles.infoRow}>
          <MapPin color="#166534" size={18} />
          <Text style={styles.infoLabel}>Distance Left</Text>
          <Text style={styles.infoValue}>14.2 km</Text>
        </View>
        <View style={styles.infoRow}>
          <Package color="#166534" size={18} />
          <Text style={styles.infoLabel}>Order ID</Text>
          <Text style={styles.infoValue}>MB-28491</Text>
        </View>
      </View>

      {/* Driver / Vehicle */}
      <View style={styles.driverCard}>
        <Text style={styles.driverTitle}>Driver / Vehicle Details</Text>
        <Text style={styles.driverName}>Raju Yadav • UP 32 AB 4521</Text>
        <Text style={styles.driverVehicle}>Tata Ace (Temperature Controlled)</Text>

        <TouchableOpacity
          style={styles.callBtn}
          onPress={() => Linking.openURL('tel:+919876543210')}
        >
          <Phone color="#fff" size={18} />
          <Text style={styles.callBtnText}>Driver ko Call Karein</Text>
        </TouchableOpacity>
      </View>

      {/* Google Maps Actions */}
      <Text style={styles.sectionTitle}>Google Maps</Text>

      <TouchableOpacity style={styles.mapsBtn} onPress={openGoogleMaps}>
        <Navigation color="#fff" size={20} />
        <Text style={styles.mapsBtnText}>Live Location – Google Maps mein Kholein</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.mapsBtnSecondary} onPress={openMapsSearch}>
        <MapPin color="#166534" size={20} />
        <Text style={styles.mapsBtnSecondaryText}>
          {isPurchase ? 'Nearby Suppliers Maps mein Dekhein' : 'Nearby Mandi Maps mein Dekhein'}
        </Text>
      </TouchableOpacity>

      {/* Timeline */}
      <Text style={styles.sectionTitle}>Order Timeline</Text>
      <View style={styles.timeline}>
        <TimelineItem title="Order Placed" time="10:15 AM" done />
        <TimelineItem title="Payment Confirmed (Escrow)" time="10:16 AM" done />
        <TimelineItem title="Vehicle Assigned" time="10:45 AM" done />
        <TimelineItem title="Out for Delivery / Pickup" time="11:20 AM" done current />
        <TimelineItem title="Delivered / Picked" time="Expected 12:00 PM" />
      </View>
    </ScrollView>
  );
}

function TimelineItem({
  title,
  time,
  done,
  current,
}: {
  title: string;
  time: string;
  done?: boolean;
  current?: boolean;
}) {
  return (
    <View style={styles.timelineItem}>
      <View
        style={[
          styles.dot,
          done && styles.dotDone,
          current && styles.dotCurrent,
        ]}
      />
      <View style={{ flex: 1 }}>
        <Text style={[styles.timelineTitle, current && { color: '#166534', fontWeight: '700' }]}>
          {title}
        </Text>
        <Text style={styles.timelineTime}>{time}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 16, paddingBottom: 40 },
  statusCard: {
    backgroundColor: '#ecfdf5',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#bbf7d0',
  },
  statusIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  statusTitle: { fontSize: 18, fontWeight: '700', color: '#166534' },
  statusSub: { fontSize: 13, color: '#4b5563', marginTop: 4, textAlign: 'center' },
  infoCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16,
    marginBottom: 16,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    gap: 10,
  },
  infoLabel: { flex: 1, fontSize: 13, color: '#64748b' },
  infoValue: { fontSize: 14, fontWeight: '700', color: '#1e293b' },
  driverCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16,
    marginBottom: 16,
  },
  driverTitle: { fontSize: 13, fontWeight: '600', color: '#64748b', marginBottom: 6 },
  driverName: { fontSize: 15, fontWeight: '700', color: '#1e293b' },
  driverVehicle: { fontSize: 13, color: '#475569', marginTop: 2, marginBottom: 12 },
  callBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#166534',
    borderRadius: 10,
    paddingVertical: 12,
    gap: 8,
  },
  callBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 10,
    marginTop: 4,
  },
  mapsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#166534',
    borderRadius: 12,
    paddingVertical: 14,
    gap: 10,
    marginBottom: 10,
  },
  mapsBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  mapsBtnSecondary: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingVertical: 14,
    gap: 10,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#166534',
  },
  mapsBtnSecondaryText: { color: '#166534', fontWeight: '600', fontSize: 13 },
  timeline: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16,
  },
  timelineItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
    gap: 12,
  },
  dot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#e2e8f0',
    marginTop: 3,
  },
  dotDone: { backgroundColor: '#166534' },
  dotCurrent: { backgroundColor: '#f59e0b' },
  timelineTitle: { fontSize: 14, color: '#1e293b' },
  timelineTime: { fontSize: 12, color: '#64748b', marginTop: 2 },
});
