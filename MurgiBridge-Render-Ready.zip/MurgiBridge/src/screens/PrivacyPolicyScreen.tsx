import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function PrivacyPolicyScreen() {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Privacy Policy</Text>
      <Text style={styles.updated}>Last updated: October 2026</Text>

      <Text style={styles.heading}>1. Introduction</Text>
      <Text style={styles.para}>
        MurgiBridge ("we", "our", or "the App") is a poultry farming support application for farmers
        in India. This Privacy Policy explains what information we collect, how we use it, and your
        rights regarding that information.
      </Text>

      <Text style={styles.heading}>2. Information We Collect</Text>
      <Text style={styles.para}>
        • Account information: name, phone number, farm location (village/district){'\n'}
        • Farm details: bird type, capacity, and related farming data you provide{'\n'}
        • Photos: images of birds you upload for expert/doctor opinion or disease scanning{'\n'}
        • Device permissions: Camera and Photos (only when you choose to upload media){'\n'}
        • Order and transaction details when you buy or sell through the App
      </Text>

      <Text style={styles.heading}>3. How We Use Your Information</Text>
      <Text style={styles.para}>
        • To provide expert and doctor consultation services{'\n'}
        • To facilitate buy/sell of chicks, feed, and birds{'\n'}
        • To show relevant mandi rates and nearby suppliers{'\n'}
        • To improve the App and send important service notifications{'\n'}
        • We do not sell your personal data to third parties
      </Text>

      <Text style={styles.heading}>4. Camera and Photos</Text>
      <Text style={styles.para}>
        Camera and photo library access is used only when you explicitly choose to attach a photo
        for disease scanning or expert opinion. Images are shared only with the selected doctor or
        expert for that consultation.
      </Text>

      <Text style={styles.heading}>5. Payments</Text>
      <Text style={styles.para}>
        When payment gateway is enabled, card/UPI details are processed by the payment provider
        (e.g. Razorpay). We do not store full card numbers on our servers.
      </Text>

      <Text style={styles.heading}>6. Data Retention</Text>
      <Text style={styles.para}>
        We retain account and order data as long as your account is active or as required by law.
        You may request deletion of your account and associated data by contacting support.
      </Text>

      <Text style={styles.heading}>7. Your Rights</Text>
      <Text style={styles.para}>
        You may request access, correction, or deletion of your personal data. Contact us at
        support@murgibridge.com for any privacy-related requests.
      </Text>

      <Text style={styles.heading}>8. Contact</Text>
      <Text style={styles.para}>
        For questions about this Privacy Policy:{'\n'}
        Email: support@murgibridge.com{'\n'}
        App: Profile → Helpline
      </Text>

      <Text style={styles.footer}>
        By using MurgiBridge you agree to this Privacy Policy.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 20, paddingBottom: 48 },
  title: { fontSize: 22, fontWeight: '800', color: '#0f172a', marginBottom: 4 },
  updated: { fontSize: 12, color: '#94a3b8', marginBottom: 20 },
  heading: {
    fontSize: 15,
    fontWeight: '700',
    color: '#166534',
    marginTop: 16,
    marginBottom: 6,
  },
  para: { fontSize: 14, color: '#334155', lineHeight: 22 },
  footer: {
    marginTop: 28,
    fontSize: 13,
    color: '#64748b',
    fontStyle: 'italic',
    textAlign: 'center',
  },
});
