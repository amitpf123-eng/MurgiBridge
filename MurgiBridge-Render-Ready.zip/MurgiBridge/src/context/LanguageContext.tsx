import React, { createContext, useContext, useState, ReactNode } from 'react';

export type LangCode =
  | 'hi'
  | 'en'
  | 'bn'
  | 'te'
  | 'mr'
  | 'ta'
  | 'gu'
  | 'kn'
  | 'ml'
  | 'pa'
  | 'or'
  | 'as';

export const LANGUAGES: { code: LangCode; name: string; native: string }[] = [
  { code: 'hi', name: 'Hindi', native: 'हिन्दी' },
  { code: 'en', name: 'English', native: 'English' },
  { code: 'bn', name: 'Bengali', native: 'বাংলা' },
  { code: 'te', name: 'Telugu', native: 'తెలుగు' },
  { code: 'mr', name: 'Marathi', native: 'मराठी' },
  { code: 'ta', name: 'Tamil', native: 'தமிழ்' },
  { code: 'gu', name: 'Gujarati', native: 'ગુજરાતી' },
  { code: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ' },
  { code: 'ml', name: 'Malayalam', native: 'മലയാളം' },
  { code: 'pa', name: 'Punjabi', native: 'ਪੰਜਾਬੀ' },
  { code: 'or', name: 'Odia', native: 'ଓଡ଼ିଆ' },
  { code: 'as', name: 'Assamese', native: 'অসমীয়া' },
];

// Simple translations for key UI texts
const translations: Record<LangCode, Record<string, string>> = {
  hi: {
    home: 'होम',
    buy: 'खरीदो',
    sell: 'बेचो',
    training: 'ट्रेनिंग',
    profile: 'प्रोफाइल',
    greeting: 'नमस्ते किसान भाई',
    welcome: 'मुर्गीब्रिज में आपका स्वागत है',
    payNow: 'अभी भुगतान करें',
    language: 'भाषा बदलें',
    trackOrder: 'ऑर्डर ट्रैक करें',
    openMaps: 'Google Maps में खोलें',
  },
  en: {
    home: 'Home',
    buy: 'Buy',
    sell: 'Sell',
    training: 'Training',
    profile: 'Profile',
    greeting: 'Hello Farmer',
    welcome: 'Welcome to MurgiBridge',
    payNow: 'Pay Now',
    language: 'Change Language',
    trackOrder: 'Track Order',
    openMaps: 'Open in Google Maps',
  },
  bn: {
    home: 'হোম',
    buy: 'কিনুন',
    sell: 'বিক্রি',
    training: 'প্রশিক্ষণ',
    profile: 'প্রোফাইল',
    greeting: 'নমস্কার কৃষক',
    welcome: 'মুরগিব্রিজে স্বাগতম',
    payNow: 'এখনই পেমেন্ট করুন',
    language: 'ভাষা পরিবর্তন',
    trackOrder: 'অর্ডার ট্র্যাক',
    openMaps: 'Google Maps-এ খুলুন',
  },
  te: {
    home: 'హోమ్',
    buy: 'కొనండి',
    sell: 'అమ్మండి',
    training: 'శిక్షణ',
    profile: 'ప్రొఫైల్',
    greeting: 'నమస్కారం రైతు',
    welcome: 'ముర్గిబ్రిడ్జ్‌కు స్వాగతం',
    payNow: 'ఇప్పుడు చెల్లించండి',
    language: 'భాష మార్చండి',
    trackOrder: 'ఆర్డర్ ట్రాక్',
    openMaps: 'Google Mapsలో తెరవండి',
  },
  mr: {
    home: 'होम',
    buy: 'खरेदी',
    sell: 'विक्री',
    training: 'प्रशिक्षण',
    profile: 'प्रोफाइल',
    greeting: 'नमस्कार शेतकरी',
    welcome: 'मुर्गीब्रिजमध्ये स्वागत',
    payNow: 'आता पेमेंट करा',
    language: 'भाषा बदला',
    trackOrder: 'ऑर्डर ट्रॅक',
    openMaps: 'Google Maps मध्ये उघडा',
  },
  ta: {
    home: 'முகப்பு',
    buy: 'வாங்க',
    sell: 'விற்க',
    training: 'பயிற்சி',
    profile: 'சுயவிவரம்',
    greeting: 'வணக்கம் விவசாயி',
    welcome: 'முர்கிபிரிட்ஜிற்கு வரவேற்கிறோம்',
    payNow: 'இப்போது செலுத்துங்கள்',
    language: 'மொழி மாற்று',
    trackOrder: 'ஆர்டர் ட்ராக்',
    openMaps: 'Google Maps-ல் திறக்க',
  },
  gu: {
    home: 'હોમ',
    buy: 'ખરીદો',
    sell: 'વેચો',
    training: 'ટ્રેનિંગ',
    profile: 'પ્રોફાઇલ',
    greeting: 'નમસ્તે ખેડૂત',
    welcome: 'મુર્ગીબ્રિજમાં આપનું સ્વાગત',
    payNow: 'હમણાં પેમેન્ટ કરો',
    language: 'ભાષા બદલો',
    trackOrder: 'ઓર્ડર ટ્રેક',
    openMaps: 'Google Mapsમાં ખોલો',
  },
  kn: {
    home: 'ಹೋಮ್',
    buy: 'ಖರೀದಿ',
    sell: 'ಮಾರಾಟ',
    training: 'ತರಬೇತಿ',
    profile: 'ಪ್ರೊಫೈಲ್',
    greeting: 'ನಮಸ್ಕಾರ ರೈತ',
    welcome: 'ಮುರ್ಗಿಬ್ರಿಡ್ಜ್‌ಗೆ ಸ್ವಾಗತ',
    payNow: 'ಈಗ ಪಾವತಿ ಮಾಡಿ',
    language: 'ಭಾಷೆ ಬದಲಾಯಿಸಿ',
    trackOrder: 'ಆರ್ಡರ್ ಟ್ರ್ಯಾಕ್',
    openMaps: 'Google Mapsನಲ್ಲಿ ತೆರೆಯಿರಿ',
  },
  ml: {
    home: 'ഹോം',
    buy: 'വാങ്ങുക',
    sell: 'വിൽക്കുക',
    training: 'പരിശീലനം',
    profile: 'പ്രൊഫൈൽ',
    greeting: 'നമസ്കാരം കർഷകൻ',
    welcome: 'മുർഗിബ്രിഡ്ജിലേക്ക് സ്വാഗതം',
    payNow: 'ഇപ്പോൾ പണമടയ്ക്കുക',
    language: 'ഭാഷ മാറ്റുക',
    trackOrder: 'ഓർഡർ ട്രാക്ക്',
    openMaps: 'Google Maps-ൽ തുറക്കുക',
  },
  pa: {
    home: 'ਹੋਮ',
    buy: 'ਖਰੀਦੋ',
    sell: 'ਵੇਚੋ',
    training: 'ਟ੍ਰੇਨਿੰਗ',
    profile: 'ਪ੍ਰੋਫਾਈਲ',
    greeting: 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ ਕਿਸਾਨ',
    welcome: 'ਮੁਰਗੀਬ੍ਰਿਜ ਵਿੱਚ ਜੀ ਆਇਆਂ ਨੂੰ',
    payNow: 'ਹੁਣ ਭੁਗਤਾਨ ਕਰੋ',
    language: 'ਭਾਸ਼ਾ ਬਦਲੋ',
    trackOrder: 'ਆਰਡਰ ਟਰੈਕ',
    openMaps: 'Google Maps ਵਿੱਚ ਖੋਲ੍ਹੋ',
  },
  or: {
    home: 'ହୋମ୍',
    buy: 'କିଣନ୍ତୁ',
    sell: 'ବିକ୍ରି',
    training: 'ତାଲିମ',
    profile: 'ପ୍ରୋଫାଇଲ୍',
    greeting: 'ନମସ୍କାର କୃଷକ',
    welcome: 'ମୁର୍ଗିବ୍ରିଜରେ ସ୍ୱାଗତ',
    payNow: 'ବର୍ତ୍ତମାନ ପେମେଣ୍ଟ କରନ୍ତୁ',
    language: 'ଭାଷା ବଦଳାନ୍ତୁ',
    trackOrder: 'ଅର୍ଡର ଟ୍ରାକ୍',
    openMaps: 'Google Mapsରେ ଖୋଲନ୍ତୁ',
  },
  as: {
    home: 'হোম',
    buy: 'কিনক',
    sell: 'বিক্ৰী',
    training: 'প্ৰশিক্ষণ',
    profile: 'প্ৰফাইল',
    greeting: 'নমস্কাৰ কৃষক',
    welcome: 'মুৰ্গিব্ৰিজত স্বাগতম',
    payNow: 'এতিয়াই পেমেণ্ট কৰক',
    language: 'ভাষা সলনি কৰক',
    trackOrder: 'অৰ্ডাৰ ট্ৰেক',
    openMaps: 'Google Maps-ত খোলক',
  },
};

type LanguageContextType = {
  lang: LangCode;
  setLang: (code: LangCode) => void;
  t: (key: string) => string;
};

const LanguageContext = createContext<LanguageContextType>({
  lang: 'hi',
  setLang: () => {},
  t: (key) => key,
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<LangCode>('hi');

  const t = (key: string) => {
    return translations[lang]?.[key] || translations['en'][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
