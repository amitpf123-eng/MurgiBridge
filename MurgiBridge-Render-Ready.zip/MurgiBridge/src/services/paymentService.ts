import { apiRequest } from './api';
import {
  PAYMENT_CONFIG,
  isPaymentApiConfigured,

} from '../config/payment';

export type PaymentMethod = 'upi' | 'card' | 'netbanking';

export interface CreateOrderParams {
  orderId: string;
  purpose: string;
  method: PaymentMethod;
  customerName?: string;
  customerPhone?: string;
  customerEmail?: string;
}

export interface RazorpayOrder {
  id: string;
  amount: number;
  currency: string;
  receipt?: string;
  keyId?: string;
}

export interface PaymentSuccessResult {
  razorpay_payment_id: string;
  razorpay_order_id: string;
  razorpay_signature: string;
}

export async function createRazorpayOrder(
  params: CreateOrderParams
): Promise<RazorpayOrder> {
  if (!isPaymentApiConfigured()) {
    throw new Error(
      'Payment server is not configured. Set paymentApiUrl in app config.'
    );
  }

  const data = await apiRequest<any>('/payments/create-order', { method: 'POST', body: JSON.stringify({ orderId: params.orderId }) });
  if (!data?.id || !data?.amount) {
    throw new Error('Invalid order response from server');
  }
  return data as RazorpayOrder;
}

export async function verifyPaymentOnServer(
  result: PaymentSuccessResult
): Promise<{ verified: boolean; message?: string }> {
  if (!isPaymentApiConfigured()) {
    return { verified: false, message: 'Payment server not configured' };
  }

  try {
    const data = await apiRequest<any>('/payments/verify', { method: 'POST', body: JSON.stringify(result) });
    return { verified: !!data.verified, message: data.message };
  } catch (error: any) {
    return { verified: false, message: error.message || 'Payment verification failed' };
  }
}

export function buildCheckoutOptions(
  order: RazorpayOrder,
  params: CreateOrderParams
): Record<string, unknown> {
  return {
    description: params.purpose,
    currency: order.currency || PAYMENT_CONFIG.currency,
    key: order.keyId || PAYMENT_CONFIG.razorpayKeyId,
    amount: order.amount,
    order_id: order.id,
    name: PAYMENT_CONFIG.companyName,
    prefill: {
      name: params.customerName || '',
      contact: params.customerPhone || '',
      email: params.customerEmail || '',
    },
    theme: { color: PAYMENT_CONFIG.themeColor },
    notes: {
      purpose: params.purpose,
      app: 'MurgiBridge',
    },
  };
}

export { isPaymentApiConfigured };
