async function api(path, options = {}) {
  const base = (window.MURGI_CONFIG?.apiBaseUrl || window.location.origin).replace(/\/$/, '');
  let res;
  try {
    res = await fetch(`${base}${path}`, {
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...(options.headers || {}),
      },
      ...options,
    });
  } catch (err) {
    throw new Error(
      `Backend se connect nahi ho paya (${base}). Server chalao: cd backend && npm run dev`
    );
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || data.message || `HTTP ${res.status}`);
  }
  return data;
}

async function createOrder({ amountPaise, purpose, method, customer }) {
  return api('/payments/create-order', {
    method: 'POST',
    body: JSON.stringify({
      amount: amountPaise,
      currency: 'INR',
      purpose,
      method,
      customer: customer || {},
    }),
  });
}

async function verifyPayment(payload) {
  return api('/payments/verify', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

async function healthCheck() {
  return api('/health');
}

async function fetchServerConfig() {
  return api('/api/config');
}
