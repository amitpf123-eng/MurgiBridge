(function () {
  // When frontend is served by backend (recommended), use same origin.
  // Override anytime from Settings page (saved in localStorage).
  const savedApi = localStorage.getItem('murgi_api');
  const savedKey = localStorage.getItem('murgi_rzp_key');

  const defaultApi =
    savedApi ||
    (typeof window !== 'undefined' && window.location && window.location.origin
      ? window.location.origin
      : 'http://localhost:4000');

  window.MURGI_CONFIG = {
    apiBaseUrl: defaultApi,
    razorpayKeyId: savedKey || '',
    appName: 'MurgiBridge',
  };

  // Load public key from backend /api/config when not set locally
  window.MURGI_CONFIG.ready = (async function loadServerConfig() {
    try {
      const base = window.MURGI_CONFIG.apiBaseUrl.replace(/\/$/, '');
      const res = await fetch(base + '/api/config');
      if (!res.ok) return;
      const data = await res.json();
      if (!window.MURGI_CONFIG.razorpayKeyId && data.razorpayKeyId) {
        window.MURGI_CONFIG.razorpayKeyId = data.razorpayKeyId;
      }
      window.MURGI_CONFIG.mockMode = !!data.mockMode;
      window.MURGI_CONFIG.serverConfig = data;
    } catch (_) {
      /* backend may be on another port during static-only serve */
    }
  })();
})();
