(function () {
  const healthStatus = document.getElementById('healthStatus');
  const healthDetail = document.getElementById('healthDetail');
  const rzpStatus = document.getElementById('rzpStatus');
  const rzpMode = document.getElementById('rzpMode');
  const apiUrl = document.getElementById('apiUrl');
  const log = document.getElementById('log');
  const statusBox = document.getElementById('statusBox');

  function currentApi() {
    return (window.MURGI_CONFIG?.apiBaseUrl || window.location.origin).replace(/\/$/, '');
  }

  apiUrl.textContent = currentApi();

  async function refresh() {
    statusBox.innerHTML = '';
    apiUrl.textContent = currentApi();
    healthStatus.textContent = 'Checking…';
    healthStatus.style.color = '';
    try {
      if (window.MURGI_CONFIG?.ready) await window.MURGI_CONFIG.ready;
      const h = await healthCheck();
      healthStatus.textContent = 'Connected';
      healthStatus.style.color = '#166534';
      healthDetail.textContent = (h.service || 'API') + (h.frontend ? ' · frontend attached' : '');

      if (h.mockMode) {
        rzpStatus.textContent = 'Mock mode';
        rzpStatus.style.color = '#b45309';
        rzpMode.textContent = 'No keys — test orders only';
        statusBox.innerHTML =
          '<div class="alert alert-warn">Backend connected (mock). Real payments: backend/.env mein Razorpay keys daalo aur server restart karo.</div>';
      } else if (h.razorpayConfigured) {
        rzpStatus.textContent = 'Configured';
        rzpStatus.style.color = '#166534';
        rzpMode.textContent = 'Mode: ' + (h.mode || 'test');
        statusBox.innerHTML =
          '<div class="alert alert-success">Frontend ↔ Backend connected. Razorpay ' +
          (h.mode || 'test') +
          ' ready.</div>';
      } else {
        rzpStatus.textContent = 'Not configured';
        rzpStatus.style.color = '#b45309';
        rzpMode.textContent = '—';
      }
    } catch (e) {
      healthStatus.textContent = 'Disconnected';
      healthStatus.style.color = '#dc2626';
      healthDetail.textContent = e.message;
      rzpStatus.textContent = 'Unknown';
      rzpMode.textContent = '—';
      statusBox.innerHTML = '<div class="alert alert-error">' + e.message + '</div>';
    }
  }

  document.getElementById('refreshBtn').addEventListener('click', refresh);
  document.getElementById('testOrderBtn').addEventListener('click', async () => {
    log.textContent = 'Creating order via ' + currentApi() + ' …';
    try {
      const order = await createOrder({
        amountPaise: 10000,
        purpose: 'Dashboard test order',
        method: 'upi',
        customer: { name: 'Test Farmer' },
      });
      log.textContent = JSON.stringify(order, null, 2);
    } catch (e) {
      log.textContent = 'Error: ' + e.message;
    }
  });

  refresh();
})();
