# MurgiBridge Web Frontend

**Connected to backend** — recommended way: backend serves this folder.

## Run (connected)

```bash
cd backend
cp .env.example .env   # optional Razorpay keys
npm install
npm start
```

Open **http://localhost:4000**

| URL | Page |
|-----|------|
| `/` | Home |
| `/pay` | Checkout → `POST /payments/create-order` |
| `/dashboard` | Health + test order |
| `/settings` | API URL / Key override |

Same origin = no CORS issues. Frontend auto-loads Key ID from `GET /api/config`.

## Flow

1. Page load → `GET /health` + `GET /api/config`
2. Pay click → `POST /payments/create-order`
3. Razorpay checkout (or mock success)
4. `POST /payments/verify`

Without Razorpay keys, backend returns **mock orders** so you can verify the connection end-to-end.
