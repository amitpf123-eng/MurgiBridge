# Run full stack (API + Frontend connected)

```bash
cd backend
cp .env.example .env   # once
npm install
npm start
```

Browser: http://localhost:4000
